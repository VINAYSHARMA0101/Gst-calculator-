# GST Calculator (Android)
GitHub par upload karte hi "Actions" tab mein APK apne aap ban jaata hai.
Phir repo ke "Releases" -> "GST Calculator APK" -> GST-Calculator.apk download karke phone par install karein.
